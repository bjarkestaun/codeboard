//create mock elements for browser testing
$('#mock-canvas').append('<canvas id="whiteboard" width="20px" height="20px"></canvas>');
$('#mock-canvas').append('<button class="new"></button>');
$('#mock-canvas').append('<div class="palette"><input type="checkbox" value="None" id="red" name="check" ng-click="changePen("red")"/></div>');
